// OpenWeb
// Created by Jacob Boldman, Shaun Loftin, and Ryan Sellars
// Used for personal use only, no professional replication
//
// In many OpenCode projects there are:
// an HTML Page, CSS attachment, additional scripts, or more.
// All of these files can be loaded in a text editor, Brackets (a free software),
// Adobe Dreamweaver, Notepad ++, or any other web/code editor.
// Additional assets such as pictures may be included as well.
// 
// The final product will be included in the .zip file, feel free
// to use the raw code provided or recreate it yourself.
//
// Enjoy!

Tutorial: Attaching CSS Tutorial

CSS can be embedded into your website 3 different ways.

Inline:
<a style="color:#FFF"></a>

It will go into your HTML tag as shown.

External Style Sheet:

<link rel="stylesheet" type="text/css" href="stylesheets/main.css">

The tag above will go into your <head> tag!

Style Tag:

<style>
	a {color:#FFF;}
</style>

The style tag will go into the head of your website.