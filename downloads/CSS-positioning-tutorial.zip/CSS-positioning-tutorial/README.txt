// OpenWeb
// Created by Jacob Boldman, Shaun Loftin, and Ryan Sellars
// Used for personal use only, no professional replication
//
// In many OpenCode projects there are:
// an HTML Page, CSS attachment, additional scripts, or more.
// All of these files can be loaded in a text editor, Brackets (a free software),
// Adobe Dreamweaver, Notepad ++, or any other web/code editor.
// Additional assets such as pictures may be included as well.
// 
// The final product will be included in the .zip file, feel free
// to use the raw code provided or recreate it yourself.
//
// Enjoy!

Tutorial: CSS Positioning Tutorial

CSS is a powerful language used to format, design, and code the World Wide Web.
However, you must use the correct positioning attribute to format it correctly.

There are 3 that OpenWeb uses primarily and will focus on in this lesson.

absolute - stays in the exact positon defined, scrolls with page 
relative - places the object in order with the HTML structure
fixed - stays in that spot despite scrolling

These are defined with the `position:` tag in CSS.

You can also position an element in addition to the position element by using left:,
right:, top:, and/or bottom:

Check out our example to see more!
