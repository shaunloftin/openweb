// OpenWeb
// Created by Jacob Boldman, Shaun Loftin, and Ryan Sellars
// Used for personal use only, no professional replication
//
// In many OpenCode projects there are:
// an HTML Page, CSS attachment, additional scripts, or more.
// All of these files can be loaded in a text editor, Brackets (a free software),
// Adobe Dreamweaver, Notepad ++, or any other web/code editor.
// Additional assets such as pictures may be included as well.
// 
// The final product will be included in the .zip file, feel free
// to use the raw code provided or recreate it yourself.
//
// Enjoy!

Tutorial: HTML Comment Tutorial

All HTML comments are defined by starting with <!-- and ended with -->
Comments are used to annotate and comment on your code for others
to see and understand what the function of the code is.

<!-- Try it! -->