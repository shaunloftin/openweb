var points = [40, 100, 1, 5, 25, 10]; // This is a comment!
points.sort(function(a, b){return a - b}); // This is another comment!