ECHO "Hello World!<br>"; /* This is a comment! */
echo "Hello World!<br>"; // This is also a comment
EcHo "Hello World!<br>"; # This is also a comment