// OpenWeb
// Created by Jacob Boldman, Shaun Loftin, and Ryan Sellars
// Used for personal use only, no professional replication
//
// In many OpenCode projects there are:
// an HTML Page, CSS attachment, additional scripts, or more.
// All of these files can be loaded in a text editor, Brackets (a free software),
// Adobe Dreamweaver, Notepad ++, or any other web/code editor.
// Additional assets such as pictures may be included as well.
// 
// The final product will be included in the .zip file, feel free
// to use the raw code provided or recreate it yourself.
//
// Enjoy!

Tutorial: JS Variable Tutorial

At the basis of every (java)script, there are variables assigned to store
data, names, numbers, or anything needed later on in the code. In order to
learn more advanced Javascript methods, one must learn how variables are defined.

First, you must declare that you are defining a variable.

var // That is how you do it.

Next, you must define the name of the variable (in which it can be called):

var variableA // so it is called Variable A

Finally, you follow the first two with an equal sign, then define the actual
content of the variable using "".

Final example:

var variableA = "23"


That's it! Now you are a Javascript master!

Learn more at openweb.shaunloftin.com 