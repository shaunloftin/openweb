// OpenWeb
// Created by Jacob Boldman, Shaun Loftin, and Ryan Sellars
// Used for personal use only, no professional replication
//
// In many OpenCode projects there are:
// an HTML Page, CSS attachment, additional scripts, or more.
// All of these files can be loaded in a text editor, Brackets (a free software),
// Adobe Dreamweaver, Notepad ++, or any other web/code editor.
// Additional assets such as pictures may be included as well.
// 
// The final product will be included in the .zip file, feel free
// to use the raw code provided or recreate it yourself.
//
// Enjoy!

Tutorial: CSS Link Selector Tutorial

Links in CSS have an interesting style of defintion due to their 4 different states.

In CSS, links have for different states.

active- defines when the link is actually active and in use
hover- when the cursor is hovered over the link
visited - (blue by default) in this state after the link have been visited recently or before
link- not clicked, not currently active

They are defined after declaring a in CSS by using a colon.

Check out our CSS example to see more!

