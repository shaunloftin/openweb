// OpenWeb
// Created by Jacob Boldman, Shaun Loftin, and Ryan Sellars
// Used for personal use only, no professional replication
//
// In many OpenCode projects there are:
// an HTML Page, CSS attachment, additional scripts, or more.
// All of these files can be loaded in a text editor, Brackets (a free software),
// Adobe Dreamweaver, Notepad ++, or any other web/code editor.
// Additional assets such as pictures may be included as well.
// 
// The final product will be included in the .zip file, feel free
// to use the raw code provided or recreate it yourself.
//
// Enjoy!

Tutorial: Page Margin Tutorial

Page Margins can be essential to any website when used effectively. Margins are 
usually incorporated in order to focus content of the website in the middle of the 
page, in order to avoid confusion, excess of white space, and eye strain.

For the OpenWeb website, we ultimately determined on 65% page margins, meaning all
of the content is focused on the inner 65% of the page. We would recommend accomplishing
this by placing your content in a wrapper, not assigning the margin to the <html> tag as 
a whole.

Check out our example for a more in-depth representation.